package com.example.newsxpress;

import com.example.newsxpress.Models.NewsHeadllines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadllines headllines);
}
